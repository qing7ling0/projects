#pragma once

#include "RPGHead.h"

class TouchAction : public Object
{
public:
	DirectionFlag actionFlag;
};