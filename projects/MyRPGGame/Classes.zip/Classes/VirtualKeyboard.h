#pragma once
class VirtualKeyboard
{
public:
	VirtualKeyboard(void);
	~VirtualKeyboard(void);
};

