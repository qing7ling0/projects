#pragma once

#include "cocos2d.h"
#include "QConfig.h"
#include "cocostudio/CocoStudio.h"
#include "RoleType.h"

using namespace cocostudio;
using namespace cocos2d;