#include "QConfig.h"
Display D_display;
