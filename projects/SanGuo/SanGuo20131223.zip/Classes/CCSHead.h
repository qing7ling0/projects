#pragma once
/**
* ����CocoStudio��ؿ�
*/
#include "extensions\cocos-ext.h"
#include "cocostudio\CocoStudio.h"
#include "gui\CocosGUI.h"

using namespace cocostudio;
using namespace gui;