#pragma once
#include "cocos2d.h"
#include "QConfig.h"
#include "CardVo.h"

USING_NS_CC;

class CardNode : public cocos2d::LayerRGBA
{
public:
	CardNode(void);
	~CardNode(void);

	virtual bool init();

	virtual void updateLabels();

	virtual void setCardVo(const CardVo &cardVo)
	{
		this->card = cardVo;
	}

	virtual void setSelected(bool selected)
	{
		if (selectSprite)
		{
			selectSprite->setVisible(selected);
		}
	}

	CREATE_FUNC(CardNode);

protected:
	LabelTTF *lifeLabel;
	LabelTTF *faliLabel;
	LabelTTF *attackLabel;
	LabelTTF *armorLabel;
	Sprite *iconSprite;
	Sprite *selectSprite;
	Sprite *cardBg;

	CardVo card;
};

