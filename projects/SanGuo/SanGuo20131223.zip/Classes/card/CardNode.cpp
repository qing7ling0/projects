#include "CardNode.h"
#include "battle\BattleControl.h"

CardNode::CardNode(void):
	lifeLabel(nullptr),
	faliLabel(nullptr),
	attackLabel(nullptr),
	armorLabel(nullptr),
	iconSprite(nullptr),
	selectSprite(nullptr),
	cardBg(nullptr)
{
}

CardNode::~CardNode(void)
{
	lifeLabel = nullptr;
	faliLabel = nullptr;
	attackLabel = nullptr;
	armorLabel = nullptr;
	iconSprite = nullptr;
	selectSprite = nullptr;
}

bool CardNode::init()
{
	if (LayerRGBA::init())
	{
		setContentSize(Size(420, 525));
		setAnchorPoint(Point(0.5f, 0.5f));
		setZOrder(ORDER_CARD);

		return true;
	}
	return false;
}

void CardNode::updateLabels()
{
	if (&card)
	{
		if (!cardBg)
		{
			cardBg = Sprite::create("images/btn/spell_normal_1.png");
			this->addChild(cardBg, -1);
		}

		char tmp[5];
		sprintf(tmp,"%d", card.life);
		
		if (lifeLabel)
		{
			lifeLabel->setString(tmp);
		}
		else
		{
			lifeLabel = LabelTTF::create(tmp, "Arial", 15);
			lifeLabel->setAnchorPoint(ccp(0.5f, 0.5f));
			lifeLabel->setPosition(ccp(70, 63));
			this->addChild(lifeLabel);
		}
		
		char tmp2[5];
		sprintf(tmp2,"%d", card.attack);
		if (attackLabel)
		{
			attackLabel->setString(tmp2);
		}
		else
		{
			attackLabel = LabelTTF::create(tmp2, "Arial", 15);
			attackLabel->setAnchorPoint(ccp(0.5f, 0.5f));
			attackLabel->setPosition(ccp(70, 530));
			this->addChild(attackLabel);
		}

		char tmp3[5];
		sprintf(tmp3,"%d", card.fali);
		if (faliLabel)
		{
			faliLabel->setString(tmp3);
		}
		else
		{
			faliLabel = LabelTTF::create(tmp3, "Arial", 15);
			faliLabel->setAnchorPoint(ccp(0.5f, 0.5f));
			faliLabel->setPosition(ccp(373, 530));
			this->addChild(faliLabel);
		}
		
		char tmp4[5];
		sprintf(tmp4,"%d", card.armor);
		if (armorLabel)
		{
			armorLabel->setString(tmp4);
		}
		else
		{
			armorLabel = LabelTTF::create(tmp4, "Arial", 15);
			armorLabel->setAnchorPoint(ccp(0.5f, 0.5f));
			armorLabel->setPosition(ccp(70, 63));
			//this->addChild(armorLabel);
		}
	}
}
