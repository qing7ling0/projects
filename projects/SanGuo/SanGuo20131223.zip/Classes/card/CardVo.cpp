#include "CardVo.h"


CardVo::CardVo(void):
	name(""),
	attack(0),
	life(0),
	maxLife(0),
	icon(0),
	type(0),
	isEnemy(false),
	fali(0),
	maxFali(0),
	armor(0),
	id(0)
{
}


CardVo::~CardVo(void)
{
}
