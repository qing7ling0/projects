#include "Card.h"


Card::Card(void):
	_cardNode(nullptr),
	_cardVo(nullptr)
{
}


Card::~Card(void)
{
	CC_SAFE_RELEASE(_cardNode);
	CC_SAFE_RELEASE(_cardVo);
}

void Card::dispose()
{

}

Card* Card::create(CardVo *cardVo)
{
	Card *card = new Card();
	card->init(cardVo);

	return card;
}

void Card::init(CardVo *cardVo)
{
	_cardVo = cardVo;
	_cardVo->retain();

	createCardNode();
}

void Card::createCardNode()
{
	if (nullptr == _cardNode)
	{
		_cardNode = CardNode::create();
		_cardNode->retain();
		_cardNode->setCardVo(*_cardVo);
		_cardNode->updateLabels();
	}
}

void Card::onDamage(int value)
{
}

void Card::onHand()
{
}

void Card::onEventHandle(int key)
{
}
void Card::onTiggerSkill(int key)
{
}
void Card::onAttack(Card card)
{
}
void Card::checkCanHand(bool tip)
{
}
	
/** �Ƿ���Ա����� */
bool Card::checkCanHitted(bool tip)
{
	return false;
}
	
/** �Ƿ���Թ��� */
bool Card::checkCanAttack(bool tip)
{
	return false;
}
	
	/** �Ƿ�����յ��˺� */
bool Card::checkCanDamage(bool tip)
{
	return false;
}
	
void Card::checkDeath()
{
}
void Card::addEffect()
{
}
void Card::updateLable()
{
}
void Card::selected()
{
}
void Card::unselected()
{
}
void Card::doing(float dt)
{
}
bool Card::isEnableTouch()
{
	return false;
}
bool Card::checkCanSelected()
{
	return false;
}

CardNode* Card::getNode()
{
	return _cardNode;
}

CardVo* Card::getCardVo()
{
	return _cardVo;
}


HeroCard::HeroCard():
	_allCardVos(Array::createWithCapacity(5)),
	_readyCards(Array::createWithCapacity(10)),
	_handCards(Array::createWithCapacity(10))
{
    _allCardVos->retain();
    _readyCards->retain();
    _handCards->retain();
	
}

HeroCard* HeroCard::create(CardVo *cardVo)
{
	HeroCard *card = new HeroCard();
	card->init(cardVo);
	card->autorelease();

	return card;
}

void HeroCard::init(CardVo *cardVo)
{
	Card::init(cardVo);
	for(int i=0; i<20; i++)
	{
		CardVo *temp = new CardVo();

		char tmp[15];
		sprintf(tmp,"%s%d", cardVo->name, i);

		temp->name = tmp;
		temp->life = i;
		temp->maxLife = i;
		temp->attack = i/4 + 2;
		temp->fali = temp->attack;
		temp->maxFali = temp->fali;
		temp->isEnemy = cardVo->isEnemy;
		temp->type = CARD_SOLDIER;
		temp->icon = cardVo->isEnemy?i : (30+i);
		temp->id = temp->icon;

		_allCardVos->addObject(temp);
		temp->release();
	}
}

HeroCard::~HeroCard()
{
    CC_SAFE_RELEASE(_allCardVos);
    CC_SAFE_RELEASE(_readyCards);
    CC_SAFE_RELEASE(_handCards);
}