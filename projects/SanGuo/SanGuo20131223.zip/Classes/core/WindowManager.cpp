#include "WindowManager.h"


WindowManager::WindowManager(void)
{
}


WindowManager::~WindowManager(void)
{
}
