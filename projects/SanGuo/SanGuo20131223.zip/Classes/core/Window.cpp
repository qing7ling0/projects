#include "Window.h"


Window::Window(void)
{
}


Window::~Window(void)
{
}
