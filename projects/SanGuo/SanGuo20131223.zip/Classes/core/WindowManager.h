#pragma once
#include "cocos2d.h"
#include "Window.h"

USING_NS_CC;

class WindowManager : Scene
{
public:
	WindowManager(void);
	~WindowManager(void);
	
    virtual bool init();

	virtual void setCurrentWindow(Window *window);
	
    CREATE_FUNC(WindowManager);
protected:
	Window *root;
};

