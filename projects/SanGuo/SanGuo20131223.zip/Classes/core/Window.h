#pragma once
#include "cocos2d.h"

USING_NS_CC;

class Window : Layer
{
public:

	Window(void);
	~Window(void);
protected:
};

