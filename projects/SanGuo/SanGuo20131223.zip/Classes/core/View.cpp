#include "View.h"


View::View(void)
{
}


View::~View(void)
{
}


bool View::isTouchIn(Touch *touch)
{
	return this->getBoundingBox().containsPoint(touch->getLocation());
}

