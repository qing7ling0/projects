﻿#pragma once
#include <string>
#include "QConfig.h"

static const std::string msg_01 = UTF8_STR(std::string("加载中..."));
static const std::string msg_02 = UTF8_STR(std::string("开始游戏"));
static const std::string msg_03 = UTF8_STR(std::string("退出游戏"));
