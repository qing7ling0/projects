#include "GameLoadingScene.h"
#include "CCSHead.h"
#include "battle\BattleScene.h"

GameLoading::~GameLoading()
{
}

bool GameLoading::init()
{
	if (Layer::init())
	{
		loginUI =UILayer::create(); 
		//��UILayer����뵽��ǰ�ĳ��� 
		this->addChild(loginUI); 
		UILayout *m_pWidget = dynamic_cast<UILayout*>(cocostudio::GUIReader::shareReader()->widgetFromJsonFile("login_1.json"));
		loginUI->addWidget(m_pWidget);

		startBtn = dynamic_cast<UIButton*> (loginUI->getWidgetByName("btn_start"));

		startBtn->setPressedActionEnabled(true);
		startBtn->setBright(true);

		startBtn->addTouchEventListener(this, SEL_TouchEvent(&GameLoading::startGameTouchListener));

		this->scheduleOnce(schedule_selector(GameLoading::loadingFinsih), 2);

		return true;
	}

	return false;
}

void GameLoading::onEnter()
{
	Layer::onEnter();

	startBtn->setVisible(false);
}

void GameLoading::doing(float dt)
{
	
}

void GameLoading::startGameTouchListener(Object* pSender, int eventType)
{
	// ����ɹ�
	if (eventType == TOUCH_EVENT_ENDED)
	{
		/*startBtn->setColor(Color3B::WHITE);
		startBtn->setScale(1);*/

		Director::getInstance()->replaceScene(BattleScene::createScene());
	}
}

void GameLoading::loadingFinsih(float dt)
{
	auto *action = ScaleTo::create(0.5f, 1, 1);
	auto *action2 = EaseBounceInOut::create(action);

	startBtn->setVisible(true);
	startBtn->setScale(0.5f);
	startBtn->runAction(action2);
}