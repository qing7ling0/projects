#pragma once
#include "cocos2d.h"
#include "QConfig.h"
#include "CCSHead.h"

USING_NS_CC;

class GameLoading : public Layer
{
public:
	~GameLoading(void);

	virtual bool init();

	virtual void onEnter();
	
	void doing(float dt);

	void loadingFinsih(float dt);

	void startGameTouchListener(Object* pSender, int eventType);

	CREATE_SECNE_FUNC(GameLoading);
private:
	UILayer *loginUI;
	ActionObject *loadingBar;
	UIButton *startBtn;
};

