#pragma once
#include "cocos2d.h"
#include "QConfig.h"

class LoginScene : public cocos2d::Layer
{
public:
	~LoginScene(void);

	virtual bool init();

	CREATE_SECNE_FUNC(LoginScene);
};

