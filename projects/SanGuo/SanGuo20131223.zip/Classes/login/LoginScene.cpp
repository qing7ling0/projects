#include "LoginScene.h"


LoginScene::~LoginScene(void)
{
}


bool LoginScene::init(void)
{
	if (Layer::init())
	{
		auto startBtn = MenuItem::create();


		return true;
	}

	return false;
}
