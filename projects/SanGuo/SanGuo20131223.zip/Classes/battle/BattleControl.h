#pragma once
#include "QConfig.h"
#include "CCSHead.h"
#include "BattleDatas.h"
#include "card\Card.h"


extern const int ORDER_CARD;
extern const int ORDER_MENU;


class BattleControl : public Object
{
public:
	BattleControl(void);
	~BattleControl(void);

	static BattleControl* getInstance();

	void init();

	void load();

	void update(float dt);

	void dispose();

	bool isSelfRound();
	
	UILayout* getBattleUI()
	{
		return _battleUI;
	}

	void setBattleUI(UILayout *battleui)
	{
		_battleUI = battleui;
	}

protected:
	UILayout *_battleUI;

	BattleRound _round;

	Array *_heros;

	Scheduler *_scheduler;

	int step;
};

