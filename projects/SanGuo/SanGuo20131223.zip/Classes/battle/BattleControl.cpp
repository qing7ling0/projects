#include "BattleControl.h"

const int ORDER_CARD = 100;
const int ORDER_MENU = 200;

static BattleControl *instance = nullptr;

static int MAX_STEP = 100;

static std::string hero_self_ui = "hero_self";
static std::string hero_enemy_ui = "hero_enemy";

BattleControl::BattleControl(void):
	_heros(NULL),
	_battleUI(nullptr),
	_scheduler(nullptr),
	step(0)
{
}

BattleControl::~BattleControl(void)
{
	_battleUI = nullptr;
    CC_SAFE_RELEASE(_heros);
    CC_SAFE_RELEASE(_scheduler);

	instance = nullptr;
}

BattleControl* BattleControl::getInstance()
{
	if (nullptr == instance)
	{
		instance = new BattleControl();
		instance->init();
	}

	return instance;
}

void BattleControl::dispose()
{
	if (_scheduler)
	{
		_scheduler->unscheduleAllForTarget(this);
	}

	release();
}

void BattleControl::init()
{
	_heros = Array::createWithCapacity(2);
    _heros->retain();

	_scheduler = Director::getInstance()->getScheduler();
	_scheduler->retain();
	_scheduler->scheduleUpdateForTarget(this, 0, false);
}

void BattleControl::update(float dt)
{
	if (step <= MAX_STEP)
	{
		load();
	}
	else
	{

	}
}

void BattleControl::load()
{
	if (step == 0)
	{
		CardVo *card = new CardVo();
		card->name = "���";
		card->life = 20;
		card->maxLife = 20;
		card->attack = 2;
		card->fali = card->attack;
		card->maxFali = card->fali;
		card->isEnemy = false;
		card->type = CARD_HERO;
		card->icon = 491;
		card->id = card->icon;
		HeroCard *hero = HeroCard::create(card);
		_heros->addObject(hero);
		card->release();
	
		card = new CardVo();
		card->name = "����";
		card->life = 20;
		card->maxLife = 20;
		card->attack = 2;
		card->fali = card->attack;
		card->maxFali = card->fali;
		card->isEnemy = false;
		card->type = CARD_HERO;
		card->icon = 492;
		card->id = card->icon;
		HeroCard *enemy = HeroCard::create(card);
		_heros->addObject(enemy);
		card->release();

		step++;
	}
	else if (step == 1)
	{
		if (_heros)
		{
			Object* hero;
			CCARRAY_FOREACH(_heros, hero)
			{
				HeroCard* heroCard = static_cast<HeroCard*>(hero);
				if (heroCard)
				{
					CardNode *node = heroCard->getNode();
					const char *ui_name = (heroCard->getCardVo()->isEnemy) ? hero_enemy_ui.c_str() : hero_self_ui.c_str();
					UILayout *layer = dynamic_cast<UILayout*>(_battleUI->getChildByName(ui_name));

					node->setPosition(ccp(layer->getPosition().x+layer->getContentSize().width/2, layer->getPosition().y+layer->getContentSize().height/2));

					node->setScale(116/node->getContentSize().width);

					_battleUI->addRenderer(node, node->getZOrder());
				}
			}
		}
		step++;
	}
	else if (step == 2)
	{
		step = MAX_STEP+1;
	}
}

bool BattleControl::isSelfRound()
{
	if (_heros)
	{
        Object* hero;
		CCARRAY_FOREACH(_heros, hero)
        {
            HeroCard* heroCard = static_cast<HeroCard*>(hero);
            if (heroCard)
            {
				return heroCard->getCardVo()->id == _round.currentRoundHeroID;
            }
        }
	}

	return false;
}
