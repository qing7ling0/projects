#pragma once
#include "cocos2d.h"
#include "QConfig.h"
#include "CCSHead.h"

class BattleScene : public LayerRGBA
{
public:
	~BattleScene(void);

	virtual bool init();

	virtual void onEnter();

	virtual void onExit();

	void endRound();

	void CCSUIBtnTouchListener(Object* pSender, TouchEventType eventType);

	CREATE_SECNE_FUNC(BattleScene);

private:
	UILayout *battleUI;
	UIButton *endRoundBtn;
};

