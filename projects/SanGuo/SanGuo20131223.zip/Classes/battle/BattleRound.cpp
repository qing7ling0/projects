#include "BattleRound.h"


BattleRound::BattleRound(void)
{
}


BattleRound::~BattleRound(void)
{
}
