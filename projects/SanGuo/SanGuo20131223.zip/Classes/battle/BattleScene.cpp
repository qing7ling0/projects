#include "BattleScene.h"
#include "BattleControl.h"

BattleScene::~BattleScene(void)
{
	BattleControl::getInstance()->dispose();

	CC_SAFE_RELEASE(battleUI);
	CC_SAFE_RELEASE(endRoundBtn);
}

bool BattleScene::init(void)
{
	if (LayerRGBA::init())
	{
		UILayer *layer = UILayer::create(); 
		//��UILayer����뵽��ǰ�ĳ��� 
		this->addChild(layer); 
		UILayout *m_pWidget = dynamic_cast<UILayout*>(cocostudio::GUIReader::shareReader()->widgetFromJsonFile("battle_1.json"));
		layer->addWidget(m_pWidget);

		battleUI = dynamic_cast<UILayout*> (layer->getWidgetByName("battle_ui"));
		battleUI->retain();

		endRoundBtn = dynamic_cast<UIButton*> (layer->getWidgetByName("btn_end"));
		endRoundBtn->retain();

		endRoundBtn->addTouchEventListener(this, SEL_TouchEvent(&BattleScene::CCSUIBtnTouchListener));

		BattleControl::getInstance()->setBattleUI(battleUI);

		return true;
	}

	return false;
}

void BattleScene::onEnter(void)
{
	LayerRGBA::onEnter();
}

void BattleScene::onExit(void)
{
	LayerRGBA::onExit();
}

void BattleScene::endRound(void)
{
	CCLOG("battle scene end round");
}

void BattleScene::CCSUIBtnTouchListener(Object* pSender, TouchEventType eventType)
{
	if (eventType == TOUCH_EVENT_ENDED)
	{
		this->endRound();
	}
}
