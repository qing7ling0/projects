#pragma once
#include "QConfig.h"

struct BattleRound
{
	int roundIndex;
	int currentRoundHeroID;
};

